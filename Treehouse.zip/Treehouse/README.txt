Treehouse mailbox + generators.
Run: python3 mailbox/server.py  (prepend TREE_SRC=/path/to/src for runtime markers)
