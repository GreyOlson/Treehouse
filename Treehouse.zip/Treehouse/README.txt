Treehouse mailbox + generators.
Run the launcher, or:  python3 mailbox/server.py
Runtime markers: prepend  TREE_SRC=/path/to/YourGame/src
